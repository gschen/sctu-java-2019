package day20190919.test_11;

public interface Printx {
    public void printMyWay();
}
