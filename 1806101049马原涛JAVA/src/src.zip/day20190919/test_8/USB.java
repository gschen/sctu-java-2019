package day20190919.test_8;

public interface USB {
    public void start();
    public void stop();
}
